# Flexy-admin-Nextjs-Free
Created Nextjs With Most Popular MUI Framework
